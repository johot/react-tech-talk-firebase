import { ProductModel } from "./../product/productModel";
export const ADD_PRODUCT = "ADD_PRODUCT";
export const REMOVE_PRODUCT = "REMOVE_PRODUCT";

interface AddProductAction {
  type: string;
  product: ProductModel;
}

interface RemoveProductAction {
  type: string;
  product: ProductModel;
}

export const addProduct = (product: ProductModel): AddProductAction => {
  return {
    type: ADD_PRODUCT,
    product: product
  };
};

export const removeProduct = (product: ProductModel): RemoveProductAction => {
  return {
    type: REMOVE_PRODUCT,
    product: product
  };
};
