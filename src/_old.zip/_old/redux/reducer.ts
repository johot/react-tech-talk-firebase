import { ADD_PRODUCT, REMOVE_PRODUCT } from "./actions";
import { getProducts } from "./../product/getProducts";
import { ProductModel } from "./../product/productModel";
import { createStore } from "redux";

const initialState: AppState = {
  products: getProducts(),
  shoppingCartProducts: []
};

interface AppState {
  products: ProductModel[];
  shoppingCartProducts: ProductModel[];
}

// Reducer
export function appReducer(state: AppState, action: any): AppState {
  switch (action.type) {
    case ADD_PRODUCT:
      const addProduct = action.product as ProductModel;

      return {
        ...state,
        shoppingCartProducts: [...state.shoppingCartProducts, { ...addProduct }]
      };

    case REMOVE_PRODUCT:
      const removeProduct = action.product as ProductModel;
      var index = state.shoppingCartProducts.indexOf(removeProduct);

      return {
        ...state,
        // shoppingCartProducts: [
        //   ...state.shoppingCartProducts.slice(0, index),
        //   ...state.shoppingCartProducts.slice(index + 1)
        // ]
        shoppingCartProducts: state.shoppingCartProducts.filter(
          p => p !== removeProduct
        )
      };
  }

  if (typeof state === "undefined") {
    return initialState;
  }

  throw new Error("Unhandled action type: " + action.type);
}
