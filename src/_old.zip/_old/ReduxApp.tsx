import * as React from "react";
import "./App.css";
import { observable } from "mobx";
import { observer } from "mobx-react";
import {
  Button,
  Form,
  Container,
  List,
  Divider,
  Header,
  Grid,
  Card,
  Segment
} from "semantic-ui-react";
import { Product } from "./product/Product";
import { ProductModel } from "./product/productModel";
import { ProductList } from "./productList/ProductList";
import ShoppingCart from "./shoppingCart/ShoppingCart";
import { getProducts } from "./product/getProducts";
import { addProduct, removeProduct } from "./redux/actions";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import { Jumbotron } from "./jumbotron/Jumbotron";

interface ReduxAppProps {
  products: ProductModel[];
  shoppingCartProducts: ProductModel[];
  // Redux thingy
  dispatch: Dispatch;
}

class ReduxApp extends React.Component<ReduxAppProps> {
  constructor(props: ReduxAppProps) {
    super(props);
  }

  _addProduct = (product: ProductModel) => {
    this.props.dispatch(addProduct(product));
  };

  _removeProduct = (product: ProductModel) => {
    this.props.dispatch(removeProduct(product));
  };

  render() {
    return (
      <Container>
        (Redux)
        <Jumbotron />
        <ProductList
          products={this.props.products}
          onProductClick={this._addProduct}
        />
        <ShoppingCart
          onProductRemoved={this._removeProduct}
          products={this.props.shoppingCartProducts}
        />
      </Container>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    products: state.products,
    shoppingCartProducts: state.shoppingCartProducts
  };
};

export default connect(mapStateToProps)(ReduxApp);
