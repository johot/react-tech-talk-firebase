import * as React from "react";
import "./App.css";
import {
  Button,
  Form,
  Container as SemanticUIContainer,
  List,
  Divider,
  Header,
  Grid,
  Card,
  Segment,
  Message
} from "semantic-ui-react";
import { Product } from "./product/Product";
import { ProductModel } from "./product/productModel";
import { ProductList } from "./productList/ProductList";
import ShoppingCart from "./shoppingCart/ShoppingCart";
import { getProducts } from "./product/getProducts";
import { Jumbotron } from "./jumbotron/Jumbotron";
import { Provider, Subscribe, Container } from "unstated";
import { AppContainer } from "./unstated/appContainer";

class UnstatedApp extends React.Component<{}> {
  render() {
    return (
      <Subscribe to={[AppContainer]}>
        {appContainer => (
          <SemanticUIContainer>
            (Unstated)
            <Message>
              "When people say you don't need Redux most of the time, they
              actually mean you do need Unstated. It's like setState on fucking
              horse steroids"
            </Message>
            <Jumbotron />
            <ProductList
              products={appContainer.state.products}
              onProductClick={(appContainer as AppContainer).addProduct}
            />
            <ShoppingCart
              onProductRemoved={(appContainer as AppContainer).removeProduct}
              products={appContainer.state.shoppingCartProducts}
            />
          </SemanticUIContainer>
        )}
      </Subscribe>
    );
  }
}

export default UnstatedApp;
