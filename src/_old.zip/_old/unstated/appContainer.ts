import { Container } from "unstated";
import { ProductModel } from "../product/productModel";
import { getProducts } from "../product/getProducts";

interface AppState {
  products: ProductModel[];
  shoppingCartProducts: ProductModel[];
}

export class AppContainer extends Container<AppState> {
  state: AppState = {
    products: getProducts(),
    shoppingCartProducts: []
  };

  addProduct = (product: ProductModel) => {
    this.setState({
      shoppingCartProducts: [...this.state.shoppingCartProducts, { ...product }]
    });
  };

  removeProduct = (product: ProductModel) => {
    var index = this.state.shoppingCartProducts.indexOf(product);
    this.setState({
      shoppingCartProducts: this.state.shoppingCartProducts.filter(
        p => p !== product
      )
    });
  };
}
